import React from "react";
import { createRoot } from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  Route,
  Link,
  Outlet,
  createRoutesFromElements,
} from "react-router-dom";
import Products from "./routes/Products";
import Home from "./routes/Home";
import Reports from "./routes/Reports";
import Navbar from "./components/Navbar";
import "./App.css";
import Photography from "./routes/Photography";

const AppLayout = () => (
  <>
    <Navbar />
    <Outlet />
  </>
);

// const router = createBrowserRouter(
//   createRoutesFromElements(
//     <Route element={<AppLayout />}>
//       <Route path="/" element={<Home />} />
//       <Route path="/products" element={<Products />} />
//       <Route path="/reports" element={<Reports />} />
//     </Route>
//   )
// );

const router = createBrowserRouter([
  {
    element: <AppLayout />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "products",
        element: <Products />,
      },
      {
        path: "bug",
        element: <Bug />,
      },
      {
        path: "building",
        element: <Building />,
      },
      {
        path: "food",
        element: <Food/>,
      },
      {
        path: "Nationalparks",
        element: <Nationalparks />,
      },
      {
        path: "photography",
        element: <Photography />,
      },
      {
        path: "plants",
        element: <Plants />,
      },
      {
        path: "tiles",
        element: <Tiles />,
      },
      {
        path: "wallpaper",
        element: <wallpaper />,
      },

    ],
  },
]);

createRoot(document.getElementById("root")).render(
  <RouterProvider router={router} />
);
