import React from "react";
const [image, setImage] = useState("");
const clientId = "vHTJ-wFPOjUW8Xg1LIhOFwBDGTwHoLoEx6ZvpFLTS7c";
const [result, setResult] = useState([]);
const handleChange = (event) => {
  setImage(event.target.value);
 };
 const handleSubmit = () => {
  console.log(Nationalparks);
  const url = "https://api.unsplash.com/search/photos?query=" + Nationalparks + "&client_id=" + clientId;
  //GET https://api.unsplash.com/search/photos?query=dogs
  axios.get(url).then((response) => {
  console.log(response);
  setResult(response.data.results);
  });
  };
function Nationalparks() {
  return (
    <div className="reports">
      <h1>Reports</h1>
    </div>
  );
}

export default Nationalparks;
