import React from "react";

const [image, setImage] = useState("");
const clientId = "vHTJ-wFPOjUW8Xg1LIhOFwBDGTwHoLoEx6ZvpFLTS7c";
const [result, setResult] = useState([]);
const handleChange = (event) => {
  setImage(event.target.value);
 };
 const handleSubmit = () => {
  console.log(Produts);
  const url = "https://api.unsplash.com/search/photos?query=" + Products + "&client_id=" + clientId;
  //GET https://api.unsplash.com/search/photos?query=dogs
  axios.get(url).then((response) => {
  console.log(response);
  setResult(response.data.results);
  });
  };

function Products() {
  return (
    <div className="products">
      <h1>Products</h1>
       
      <div className="input">
  <input onChange={handleChange} type="text" name="image"    placeholder="Search for images"/>
 </div>
  <button onClick={handleSubmit} type="submit">Search</button>
<div className="result">
  {result.map((image) => (
  <>
   <div className="card">
    <img src={image.urls.thumb} />
    <p className="username"> Photo by {image.user.name}</p>
    <p className="like">👍 {image.likes}</p>
   </div>
  </>
   ))}
</div>
    </div>
  );
}

export default Products;
