import React from "react";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import * as IoIcons from "react-icons/io";

export const SidebarData = [
  {
    title: "Home",
    path: "/",
    icon: <AiIcons.AiFillHome />,
    cName: "nav-text",
  },
  {
    title: "Reports",
    path: "/reports",
    icon: <IoIcons.IoIosPaper />,
    cName: "nav-text",
  },
  {
    title: "Products",
    path: "/products",
    icon: <FaIcons.IosIosPaper/>,
    cName: "nav-text",
  },
  {
    title: "Buildings",
    path: "/building",
    icon: <IoIcons.IosIosPaper/>,
    cName: "nav-text",
  },
  {
    title: "Bug",
    path: "/Bug",
    icon: <FaIcons.IosIosPaper />,
    cName: "nav-text",
  },
  {
    title: "Food",
    path: "/Food",
    icon: <IoIcons.IosIosPaper />,
    cName: "nav-text",
  },

  {
    title: "Tile",
    path: "/Tiles",
    icon: <IoIcons.IosIosPaper />,
    cName: "nav-text",
  },

  {
    title: "Wallpaper",
    path: "/Wallpaper",
    icon: <IoIcons.IosIosPaper />,
    cName: "nav-text",
  },
  {
    title: "Nationalparks",
    path: "/Nationalparks",
    icon: <IoIcons.IosIosPaper />,
    cName: "nav-text",
  },
  {
    title: "Photography",
    path: "/Photography",
    icon: <IoIcons.IosIosPaper />,
    cName: "nav-text",
  },
  {
    title: "Plants",
    path: "/Plants",
    icon: <IoIcons.IosIosPaper />,
    cName: "nav-text",
  },
];
